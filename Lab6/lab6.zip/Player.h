//
// Created by WaiWaiXi on 2021/5/21.
//

#ifndef LAB6_PLAYER_H
#define LAB6_PLAYER_H

#include <string>

using namespace std;

class Player {
public:
    string name;
    int score = 0;
};


#endif //LAB6_PLAYER_H
